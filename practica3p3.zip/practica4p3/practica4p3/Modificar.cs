﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Windows.Forms;

namespace practica4p3
{
    public partial class Modificar : Form
    {
        public Modificar(string c, string n, string p, string i)
        {
            InitializeComponent();
            lblCodigo.Text = c;
            txtNombre.Text = n;
            txtPrecio.Text = p;
            imagen.Image = Image.FromFile(i);
        }

        private void label1_Click(object sender, EventArgs e)
        {
            eliminarDelArchivo(lblCodigo.Text, txtNombre.Text, txtPrecio.Text);

        }

        private void btnModificar_Click(object sender, EventArgs e)
        {

        }
        private void eliminarDelArchivo(string i, string n, string p)
        {
            int id = Convert.ToInt32(i);
            string codigo = n.Substring(0, 2);
            int hsistema = DateTime.Now.Hour;
            codigo += hsistema.ToString();
            if (!i.Equals(""))
            {
                StreamReader archivo = File.OpenText("productos.csv");
                string renglon = "";
                StreamWriter aux = null;
                int c = 0;
                do
                {
                    try
                    {
                        renglon = archivo.ReadLine();
                        if (renglon != null)
                        {
                            string[] partes = renglon.Split(',');
                            if (partes[0].Equals(i))
                            {

                                aux = File.AppendText("Prueba.csv");
                                string cadena = codigo + "," + n + "," + p + "," + partes[3];
                                aux.WriteLine(cadena);
                                aux.Close();

                            }
                            else
                            {
                                aux = File.AppendText("Prueba.csv");
                                string cadena = partes[0] + "," + partes[1] + "," + partes[2] + "," + partes[3];
                                aux.WriteLine(cadena);
                                aux.Close();
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error", "Error");

                    }
                } while (renglon != null);
                MessageBox.Show("Datos Modificados", "ventana");
                archivo.Close();
                File.Delete("productos.csv");
                if (File.Exists("prueba.csv"))
                {
                    File.Move("prueba.csv", "productos.csv");
                    File.Delete("prueba.csv");
                }
            }

        }
    }
}
