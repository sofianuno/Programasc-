﻿namespace practica4p3
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            banner = new PictureBox();
            panel2 = new Panel();
            btncerrar = new Button();
            btnaceptar = new Button();
            txtcontraseña = new TextBox();
            txtusuario = new TextBox();
            lblcontraseña = new Label();
            lblusuario = new Label();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)banner).BeginInit();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Controls.Add(banner);
            panel1.Location = new Point(0, 12);
            panel1.Name = "panel1";
            panel1.Size = new Size(792, 200);
            panel1.TabIndex = 0;
            // 
            // banner
            // 
            banner.Location = new Point(3, 0);
            banner.Name = "banner";
            banner.Size = new Size(778, 197);
            banner.SizeMode = PictureBoxSizeMode.StretchImage;
            banner.TabIndex = 0;
            banner.TabStop = false;
            // 
            // panel2
            // 
            panel2.Controls.Add(btncerrar);
            panel2.Controls.Add(btnaceptar);
            panel2.Controls.Add(txtcontraseña);
            panel2.Controls.Add(txtusuario);
            panel2.Controls.Add(lblcontraseña);
            panel2.Controls.Add(lblusuario);
            panel2.Location = new Point(0, 218);
            panel2.Name = "panel2";
            panel2.Size = new Size(781, 236);
            panel2.TabIndex = 1;
            panel2.Paint += panel2_Paint;
            // 
            // btncerrar
            // 
            btncerrar.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btncerrar.Location = new Point(513, 185);
            btncerrar.Name = "btncerrar";
            btncerrar.Size = new Size(122, 29);
            btncerrar.TabIndex = 5;
            btncerrar.Text = "CERRAR";
            btncerrar.UseVisualStyleBackColor = true;
            btncerrar.Click += btncerrar_Click;
            // 
            // btnaceptar
            // 
            btnaceptar.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnaceptar.Location = new Point(114, 185);
            btnaceptar.Name = "btnaceptar";
            btnaceptar.Size = new Size(120, 29);
            btnaceptar.TabIndex = 4;
            btnaceptar.Text = "ACEPTAR";
            btnaceptar.UseVisualStyleBackColor = true;
            btnaceptar.Click += btnaceptar_Click;
            // 
            // txtcontraseña
            // 
            txtcontraseña.Location = new Point(334, 118);
            txtcontraseña.Name = "txtcontraseña";
            txtcontraseña.PasswordChar = 'x';
            txtcontraseña.Size = new Size(219, 27);
            txtcontraseña.TabIndex = 3;
            // 
            // txtusuario
            // 
            txtusuario.Location = new Point(334, 29);
            txtusuario.Name = "txtusuario";
            txtusuario.Size = new Size(219, 27);
            txtusuario.TabIndex = 2;
            // 
            // lblcontraseña
            // 
            lblcontraseña.AutoSize = true;
            lblcontraseña.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblcontraseña.Location = new Point(114, 125);
            lblcontraseña.Name = "lblcontraseña";
            lblcontraseña.Size = new Size(110, 20);
            lblcontraseña.TabIndex = 1;
            lblcontraseña.Text = "CONTRASEÑA";
            // 
            // lblusuario
            // 
            lblusuario.AutoSize = true;
            lblusuario.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblusuario.Location = new Point(114, 32);
            lblusuario.Name = "lblusuario";
            lblusuario.Size = new Size(76, 20);
            lblusuario.TabIndex = 0;
            lblusuario.Text = "USUARIO";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(782, 453);
            Controls.Add(panel2);
            Controls.Add(panel1);
            MaximumSize = new Size(800, 500);
            MinimumSize = new Size(800, 500);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Registro de Compra";
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)banner).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Panel panel2;
        private PictureBox banner;
        private Label lblcontraseña;
        private Label lblusuario;
        private Button btncerrar;
        private Button btnaceptar;
        private TextBox txtcontraseña;
        private TextBox txtusuario;
    }
}
