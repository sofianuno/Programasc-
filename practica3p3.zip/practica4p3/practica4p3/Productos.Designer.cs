﻿namespace practica4p3
{
    partial class Productos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            txtPrecio = new TextBox();
            txtproducto = new TextBox();
            lblcodigo2 = new Label();
            lblcodigo = new Label();
            label2 = new Label();
            lblProducto = new Label();
            btnBuscar = new Button();
            imgProducto = new PictureBox();
            panel2 = new Panel();
            btnBuscar1 = new Button();
            btnModificar = new Button();
            btnEliminar = new Button();
            btnAgregar = new Button();
            panel3 = new Panel();
            dataProductos = new DataGridView();
            Codigo = new DataGridViewTextBoxColumn();
            Producto = new DataGridViewTextBoxColumn();
            Precio = new DataGridViewTextBoxColumn();
            Foto = new DataGridViewImageColumn();
            Ruta = new DataGridViewTextBoxColumn();
            menuStrip1 = new MenuStrip();
            archivoToolStripMenuItem = new ToolStripMenuItem();
            agregarUsuarioToolStripMenuItem = new ToolStripMenuItem();
            salirToolStripMenuItem = new ToolStripMenuItem();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)imgProducto).BeginInit();
            panel2.SuspendLayout();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataProductos).BeginInit();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Controls.Add(txtPrecio);
            panel1.Controls.Add(txtproducto);
            panel1.Controls.Add(lblcodigo2);
            panel1.Controls.Add(lblcodigo);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(lblProducto);
            panel1.Controls.Add(btnBuscar);
            panel1.Controls.Add(imgProducto);
            panel1.Location = new Point(12, 41);
            panel1.Name = "panel1";
            panel1.Size = new Size(450, 410);
            panel1.TabIndex = 0;
            // 
            // txtPrecio
            // 
            txtPrecio.Location = new Point(167, 325);
            txtPrecio.Name = "txtPrecio";
            txtPrecio.Size = new Size(165, 27);
            txtPrecio.TabIndex = 7;
            // 
            // txtproducto
            // 
            txtproducto.Location = new Point(167, 253);
            txtproducto.Name = "txtproducto";
            txtproducto.Size = new Size(165, 27);
            txtproducto.TabIndex = 6;
            // 
            // lblcodigo2
            // 
            lblcodigo2.AutoSize = true;
            lblcodigo2.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblcodigo2.Location = new Point(209, 375);
            lblcodigo2.Name = "lblcodigo2";
            lblcodigo2.Size = new Size(80, 20);
            lblcodigo2.TabIndex = 5;
            lblcodigo2.Text = "sin codigo";
            // 
            // lblcodigo
            // 
            lblcodigo.AutoSize = true;
            lblcodigo.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblcodigo.Location = new Point(49, 375);
            lblcodigo.Name = "lblcodigo";
            lblcodigo.Size = new Size(58, 20);
            lblcodigo.TabIndex = 4;
            lblcodigo.Text = "Codigo";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(49, 325);
            label2.Name = "label2";
            label2.Size = new Size(52, 20);
            label2.TabIndex = 3;
            label2.Text = "Precio";
            label2.Click += label2_Click;
            // 
            // lblProducto
            // 
            lblProducto.AutoSize = true;
            lblProducto.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblProducto.Location = new Point(49, 253);
            lblProducto.Name = "lblProducto";
            lblProducto.Size = new Size(73, 20);
            lblProducto.TabIndex = 2;
            lblProducto.Text = "Producto";
            // 
            // btnBuscar
            // 
            btnBuscar.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnBuscar.Location = new Point(167, 194);
            btnBuscar.Name = "btnBuscar";
            btnBuscar.Size = new Size(137, 29);
            btnBuscar.TabIndex = 1;
            btnBuscar.Text = "Buscar Producto";
            btnBuscar.UseVisualStyleBackColor = true;
            btnBuscar.Click += btnBuscar_Click;
            // 
            // imgProducto
            // 
            imgProducto.Location = new Point(37, 14);
            imgProducto.Name = "imgProducto";
            imgProducto.Size = new Size(367, 163);
            imgProducto.TabIndex = 0;
            imgProducto.TabStop = false;
            // 
            // panel2
            // 
            panel2.Controls.Add(btnBuscar1);
            panel2.Controls.Add(btnModificar);
            panel2.Controls.Add(btnEliminar);
            panel2.Controls.Add(btnAgregar);
            panel2.Location = new Point(468, 41);
            panel2.Name = "panel2";
            panel2.Size = new Size(157, 410);
            panel2.TabIndex = 1;
            // 
            // btnBuscar1
            // 
            btnBuscar1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnBuscar1.Location = new Point(20, 316);
            btnBuscar1.Name = "btnBuscar1";
            btnBuscar1.Size = new Size(118, 59);
            btnBuscar1.TabIndex = 3;
            btnBuscar1.Text = "Buscar";
            btnBuscar1.UseVisualStyleBackColor = true;
            // 
            // btnModificar
            // 
            btnModificar.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnModificar.Location = new Point(20, 222);
            btnModificar.Name = "btnModificar";
            btnModificar.Size = new Size(118, 58);
            btnModificar.TabIndex = 2;
            btnModificar.Text = "Modificar";
            btnModificar.UseVisualStyleBackColor = true;
            btnModificar.Click += btnModificar_Click;
            // 
            // btnEliminar
            // 
            btnEliminar.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnEliminar.Location = new Point(20, 135);
            btnEliminar.Name = "btnEliminar";
            btnEliminar.Size = new Size(118, 58);
            btnEliminar.TabIndex = 1;
            btnEliminar.Text = "Eliminar";
            btnEliminar.UseVisualStyleBackColor = true;
            btnEliminar.Click += btnEliminar_Click;
            // 
            // btnAgregar
            // 
            btnAgregar.Enabled = false;
            btnAgregar.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAgregar.Location = new Point(20, 46);
            btnAgregar.Name = "btnAgregar";
            btnAgregar.Size = new Size(118, 58);
            btnAgregar.TabIndex = 0;
            btnAgregar.Text = "Agregar";
            btnAgregar.UseVisualStyleBackColor = true;
            btnAgregar.Click += btnAgregar_Click;
            // 
            // panel3
            // 
            panel3.Controls.Add(dataProductos);
            panel3.Location = new Point(631, 41);
            panel3.Name = "panel3";
            panel3.Size = new Size(491, 397);
            panel3.TabIndex = 2;
            // 
            // dataProductos
            // 
            dataProductos.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataProductos.Columns.AddRange(new DataGridViewColumn[] { Codigo, Producto, Precio, Foto, Ruta });
            dataProductos.Location = new Point(0, 29);
            dataProductos.Name = "dataProductos";
            dataProductos.RowHeadersWidth = 51;
            dataProductos.Size = new Size(491, 397);
            dataProductos.TabIndex = 0;
            dataProductos.CellClick += dataProductos_CellClick;
            // 
            // Codigo
            // 
            Codigo.HeaderText = "Codigo";
            Codigo.MinimumWidth = 6;
            Codigo.Name = "Codigo";
            Codigo.Width = 115;
            // 
            // Producto
            // 
            Producto.HeaderText = "Producto";
            Producto.MinimumWidth = 6;
            Producto.Name = "Producto";
            Producto.Width = 115;
            // 
            // Precio
            // 
            Precio.HeaderText = "Precio";
            Precio.MinimumWidth = 6;
            Precio.Name = "Precio";
            Precio.Width = 115;
            // 
            // Foto
            // 
            Foto.HeaderText = "Foto";
            Foto.ImageLayout = DataGridViewImageCellLayout.Zoom;
            Foto.MinimumWidth = 6;
            Foto.Name = "Foto";
            Foto.Width = 115;
            // 
            // Ruta
            // 
            Ruta.HeaderText = "Ruta";
            Ruta.MinimumWidth = 6;
            Ruta.Name = "Ruta";
            Ruta.Width = 125;
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(20, 20);
            menuStrip1.Items.AddRange(new ToolStripItem[] { archivoToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(1134, 28);
            menuStrip1.TabIndex = 3;
            menuStrip1.Text = "menuStrip1";
            // 
            // archivoToolStripMenuItem
            // 
            archivoToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { agregarUsuarioToolStripMenuItem, salirToolStripMenuItem });
            archivoToolStripMenuItem.Name = "archivoToolStripMenuItem";
            archivoToolStripMenuItem.Size = new Size(73, 24);
            archivoToolStripMenuItem.Text = "Archivo";
            // 
            // agregarUsuarioToolStripMenuItem
            // 
            agregarUsuarioToolStripMenuItem.Name = "agregarUsuarioToolStripMenuItem";
            agregarUsuarioToolStripMenuItem.Size = new Size(200, 26);
            agregarUsuarioToolStripMenuItem.Text = "Agregar Usuario";
            // 
            // salirToolStripMenuItem
            // 
            salirToolStripMenuItem.Name = "salirToolStripMenuItem";
            salirToolStripMenuItem.Size = new Size(200, 26);
            salirToolStripMenuItem.Text = "Salir";
            salirToolStripMenuItem.Click += salirToolStripMenuItem_Click;
            // 
            // Productos
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1134, 450);
            Controls.Add(panel3);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            MaximumSize = new Size(1152, 497);
            MinimumSize = new Size(1152, 497);
            Name = "Productos";
            Load += Productos_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)imgProducto).EndInit();
            panel2.ResumeLayout(false);
            panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataProductos).EndInit();
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Panel panel2;
        private Panel panel3;
        private Label label2;
        private Label lblProducto;
        private Button btnBuscar;
        private PictureBox imgProducto;
        private TextBox txtPrecio;
        private TextBox txtproducto;
        private Label lblcodigo2;
        private Label lblcodigo;
        private Button btnBuscar1;
        private Button btnModificar;
        private Button btnEliminar;
        private Button btnAgregar;
        private DataGridView dataProductos;
        private DataGridViewTextBoxColumn Codigo;
        private DataGridViewTextBoxColumn Producto;
        private DataGridViewTextBoxColumn Precio;
        private DataGridViewImageColumn Foto;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem archivoToolStripMenuItem;
        private ToolStripMenuItem agregarUsuarioToolStripMenuItem;
        private ToolStripMenuItem salirToolStripMenuItem;
        private DataGridViewTextBoxColumn Ruta;
    }
}