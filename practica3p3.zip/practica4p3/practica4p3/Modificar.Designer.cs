﻿namespace practica4p3
{
    partial class Modificar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btncerrar = new Button();
            btnModificar = new Button();
            txtPrecio = new TextBox();
            txtNombre = new TextBox();
            lblPrecio = new Label();
            lblNombre = new Label();
            lbl1 = new Label();
            imagen = new PictureBox();
            lblCodigo = new Label();
            ((System.ComponentModel.ISupportInitialize)imagen).BeginInit();
            SuspendLayout();
            // 
            // btncerrar
            // 
            btncerrar.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btncerrar.Location = new Point(311, 411);
            btncerrar.Name = "btncerrar";
            btncerrar.Size = new Size(122, 29);
            btncerrar.TabIndex = 11;
            btncerrar.Text = "CERRAR";
            btncerrar.UseVisualStyleBackColor = true;
            // 
            // btnModificar
            // 
            btnModificar.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnModificar.Location = new Point(45, 411);
            btnModificar.Name = "btnModificar";
            btnModificar.Size = new Size(120, 29);
            btnModificar.TabIndex = 10;
            btnModificar.Text = "Modificar";
            btnModificar.UseVisualStyleBackColor = true;
            btnModificar.Click += btnModificar_Click;
            // 
            // txtPrecio
            // 
            txtPrecio.Location = new Point(277, 328);
            txtPrecio.Name = "txtPrecio";
            txtPrecio.PasswordChar = 'x';
            txtPrecio.Size = new Size(219, 27);
            txtPrecio.TabIndex = 9;
            // 
            // txtNombre
            // 
            txtNombre.Location = new Point(277, 251);
            txtNombre.Name = "txtNombre";
            txtNombre.Size = new Size(219, 27);
            txtNombre.TabIndex = 8;
            // 
            // lblPrecio
            // 
            lblPrecio.AutoSize = true;
            lblPrecio.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblPrecio.Location = new Point(45, 335);
            lblPrecio.Name = "lblPrecio";
            lblPrecio.Size = new Size(61, 20);
            lblPrecio.TabIndex = 7;
            lblPrecio.Text = "PRECIO";
            // 
            // lblNombre
            // 
            lblNombre.AutoSize = true;
            lblNombre.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblNombre.Location = new Point(38, 254);
            lblNombre.Name = "lblNombre";
            lblNombre.Size = new Size(74, 20);
            lblNombre.TabIndex = 6;
            lblNombre.Text = "NOMBRE";
            // 
            // lbl1
            // 
            lbl1.AutoSize = true;
            lbl1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl1.Location = new Point(45, 188);
            lbl1.Name = "lbl1";
            lbl1.Size = new Size(67, 20);
            lbl1.TabIndex = 12;
            lbl1.Text = "CODIGO";
            lbl1.Click += label1_Click;
            // 
            // imagen
            // 
            imagen.Location = new Point(100, 12);
            imagen.Name = "imagen";
            imagen.Size = new Size(379, 163);
            imagen.TabIndex = 14;
            imagen.TabStop = false;
            // 
            // lblCodigo
            // 
            lblCodigo.AutoSize = true;
            lblCodigo.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblCodigo.Location = new Point(330, 194);
            lblCodigo.Name = "lblCodigo";
            lblCodigo.Size = new Size(67, 20);
            lblCodigo.TabIndex = 15;
            lblCodigo.Text = "CODIGO";
            // 
            // Modificar
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(589, 490);
            Controls.Add(lblCodigo);
            Controls.Add(imagen);
            Controls.Add(lbl1);
            Controls.Add(btncerrar);
            Controls.Add(btnModificar);
            Controls.Add(txtPrecio);
            Controls.Add(txtNombre);
            Controls.Add(lblPrecio);
            Controls.Add(lblNombre);
            MaximumSize = new Size(607, 537);
            MinimumSize = new Size(607, 537);
            Name = "Modificar";
            StartPosition = FormStartPosition.CenterParent;
            Text = "Modificar";
            ((System.ComponentModel.ISupportInitialize)imagen).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btncerrar;
        private Button btnModificar;
        private TextBox txtPrecio;
        private TextBox txtNombre;
        private Label lblPrecio;
        private Label lblNombre;
        private Label lbl1;
        private PictureBox imagen;
        private Label lblCodigo;
    }
}