﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace practica4p3
{
    public partial class Productos : Form
    {
        private string rutaimagenlocal = "", Imagenlocal = "";
        private int _id = -1;
        private string codigoArchivo;
        private string nombreP, precioP, imagenP;
        List<string> img = new List<string>();

        public Productos()
        {
            InitializeComponent();
            Mostrardatos();
            dataProductos.AllowUserToAddRows = false; // Elimina la fila en blanco del final
            dataProductos.ReadOnly = true;//Desactiva la edicion directa del dataGrid

        }


        private void Mostrardatos()
        {
            dataProductos.Rows.Clear();
            if (File.Exists("productos.csv"))
            {
                StreamReader streamReader = File.OpenText("productos.csv");
                string renglon = " ";
                int c = 0;
                do
                {
                    try
                    {
                        renglon = streamReader.ReadLine();
                        if (renglon != null)
                        {
                            string[] partes = renglon.Split(',');
                            c++;
                            dataProductos.Rows.Add(partes[0], partes[1], partes[2], Image.FromFile(partes[3]));

                        }

                    }
                    catch (Exception ex)

                    {
                        MessageBox.Show("Error");
                    }

                } while (renglon != null);
                streamReader.Close();
            }
            else
            {
                MessageBox.Show("Error, no hay datos guardados");
            }
        }



        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Productos_Load(object sender, EventArgs e)
        {

        }

        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            string productos = "productos.csv";
            StreamWriter streamWriter;
            string Productos = "productos.csv";
            string nombre = txtproducto.Text;
            string precio = txtPrecio.Text;
            if (nombre.Length == 0 || precio.Length == 0)
            {
                MessageBox.Show("Faltan datos", "Alerta");
            }
            else
            {
                string codigo = nombre.Substring(0, 2);
                int hsistema = DateTime.Now.Hour;
                codigo += hsistema.ToString();
                lblcodigo2.Text = codigo;
                streamWriter = File.AppendText(productos);
                streamWriter.Write(codigo + "," + nombre + "," + precio + "," + rutaimagenlocal);
                streamWriter.Close();
                MessageBox.Show("Producto guardado", "Mensaje");
                Mostrardatos();
                txtproducto.Text = "";// para borrar los valores que se quedan en las cajas de texto y seguir guardando
                imgProducto.Image.Dispose();
                imgProducto.Image = null;
                txtPrecio.Text = "";
                lblcodigo.Text = "";
            }

        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            string rutaImagen = " ";
            string rutacarpeta = @"\imagenes";
            string rutaraiz = @"imagenes";
            string ruta = "";
            if (txtproducto.Text.Length == 0)
            {
                MessageBox.Show("Escribe el producto primero", "Ventana");
            }
            else
            {
                int sistema = DateTime.Now.Second;
                string nombreImagen = "";
                nombreImagen = "img" + sistema.ToString() + txtproducto.Text + "png";
                ofd.Filter = "JPEG(*.JPG)|*.JPG|PNG(*.PNG)|*.PNG";
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    string[] listaDirectorios = Directory.GetDirectories(rutaraiz);

                    ruta = ofd.FileName;
                    System.IO.File.Copy(ruta, listaDirectorios[0] + nombreImagen, true);
                    imgProducto.Image = Image.FromFile(listaDirectorios[0] + nombreImagen);
                    rutaimagenlocal = listaDirectorios[0] + nombreImagen;
                }


            }

            btnAgregar.Enabled = true;
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            MessageBox.Show(_id.ToString(), "ID");
            if (_id != -1 && img.Count > 0)
            {
                string rutaRelativa = img[0];
                string rutaCompleta = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, rutaRelativa);

                foreach (DataGridViewRow row in dataProductos.Rows)
                {
                    if (row.Cells[3].Value is Image imagenCelda)
                    {
                        imagenCelda.Dispose();
                    }
                }
                if (File.Exists(rutaCompleta))
                {
                    try
                    {

                        File.Delete(rutaCompleta);
                        MessageBox.Show("Imagen Eliminada");
                        eliminarDelArchivo(_id);
                        dataProductos.Rows.RemoveAt(_id);
                        _id = -1;
                        img.Clear();
                        codigoArchivo = "";
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error al eliminar la imagen: " + ex.Message);
                    }
                }
                else
                {
                    MessageBox.Show("La imagen no fue encontrada en: " + rutaCompleta);
                }

            }
            else
            {
                MessageBox.Show("Selecciona un producto valido");
            }


        }
        private void eliminarDelArchivo(int id)
        {
            if (id != -1)
            {
                StreamReader archivo = File.OpenText("productos.csv");
                string renglon = "";
                StreamWriter aux = null;
                int c = 0;
                do
                {
                    try
                    {
                        renglon = archivo.ReadLine();
                        if (renglon != null)
                        {
                            string[] partes = renglon.Split(',');
                            if (partes[0].Equals(codigoArchivo))
                            {
                                MessageBox.Show("imagen borrada", "RutaLocal");
                            }
                            else
                            {
                                aux = File.AppendText("Prueba.csv");
                                string cadena = partes[0] + "," + partes[1] + "," + partes[2] + "," + partes[3];
                                aux.WriteLine(cadena);
                                aux.Close();
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error", "Error");

                    }
                } while (renglon != null);
                archivo.Close();
                File.Delete("productos.csv");
                if (File.Exists("prueba.csv"))
                {
                    File.Move("prueba.csv", "productos.csv");
                    File.Delete("prueba.csv");
                }
            }

        }

        private void dataProductos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            _id = e.RowIndex;

            if (_id != -1)
            {
                codigoArchivo = dataProductos.Rows[_id].Cells[0].Value.ToString();
                //Imagenlocal = dataProductos.Rows[_id].Cells[4].Value.ToString();
                img.Clear();
                img.Add(dataProductos.Rows[_id].Cells[4].Value.ToString());
                nombreP = dataProductos.Rows[_id].Cells[1].Value.ToString();
                precioP = dataProductos.Rows[_id].Cells[2].Value.ToString();
                imagenP = dataProductos.Rows[_id].Cells[4].Value.ToString();

                MessageBox.Show(Imagenlocal, "Aviso");
            }
            else
            {
                MessageBox.Show("Elige un elemento de la lista");

            }
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            Modificar modificar = new Modificar(codigoArchivo, nombreP, precioP, imagenP);
            modificar.ShowDialog();
        }
    }
}
