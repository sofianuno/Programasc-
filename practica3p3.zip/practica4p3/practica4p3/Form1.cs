namespace practica4p3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            revisarImagen();
            crearUsuario();
        }

        private void crearUsuario()
        {
            StreamWriter streamWriter;
            string usuarios = "usuarios.csv";
            if (!File.Exists(usuarios))
            {

                streamWriter = File.AppendText(usuarios);
                streamWriter.WriteLine("admin,12345,administrador");
                streamWriter.Close();

            }

        }
        private void revisarImagen()
        {
            OpenFileDialog ofd = new OpenFileDialog();
            string rutaImagen = " ";
            string rutacarpeta = @"\imagenes";
            string rutaraiz = @"imagenes";
            string ruta = "";
            Random randon = new Random();
            int nombreArchivo = randon.Next(1, 1000);
            if (!Directory.Exists(rutaraiz))
            {

                Directory.CreateDirectory(rutaraiz);
                Directory.CreateDirectory(rutaraiz + rutacarpeta);
                string[] listaDirectorios = Directory.GetDirectories(rutaraiz);//obtener la ruta raiz
                MessageBox.Show(listaDirectorios[0], "rutacarpeta");
                ofd.Filter = "JPEG(*.JPG)|*.JPG|PNG(*.PNG)|*.PNG";
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    ruta = ofd.FileName;
                    System.IO.File.Copy(ruta, listaDirectorios[0] + "banner" + ".png", true);
                    banner.Image = Image.FromFile(listaDirectorios[0] + "banner" + ".png");
                }
            }
            else
            {
                //(MessageBox.Show("la  carpeta ya existe", "mensaje");
                string[] listaDirectorios = Directory.GetDirectories(rutaraiz);
                banner.Image = Image.FromFile(listaDirectorios[0] + "banner" + ".png");
            }
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnaceptar_Click(object sender, EventArgs e)
        {
            string usuarios = "usuarios.csv";
            string dato = "";
            string cu = txtusuario.Text;
            string cp = txtcontrase�a.Text;
            bool encontro = false;
            if (cu.Length == 0 || cp.Length == 0)
            {
                MessageBox.Show("Faltan usuarios o contrase�a", "Alerta", MessageBoxButtons.OK);
            }
            else
            {
                if (File.Exists(usuarios))
                {
                    StreamReader sr = File.OpenText(usuarios);
                    do
                    {
                        dato = sr.ReadLine();
                        if (dato != null)
                        {
                            int p = dato.IndexOf(",");
                            int p2 = dato.IndexOf(",",p+1);
                            string u = dato.Substring(0, p);
                            string pa = dato.Substring(p + 1, p2-p-1);
                            
                            if (u.Equals(cu) && pa.Equals(cp))
                            {
                                encontro = true;
                                break;

                            }

                        }

                    } while (dato != null);
                    sr.Close();
                    if (encontro)
                    {
                        this.Hide();
                        Productos productos = new Productos();
                        productos.ShowDialog();
                    }
                    else
                    {
                        MessageBox.Show("Usuario no existe", "Alerta");
                    }

                }
                else
                {
                    MessageBox.Show("Este archivo no es encontrado", "Alerta");
                }

            }


        }

        private void btncerrar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
