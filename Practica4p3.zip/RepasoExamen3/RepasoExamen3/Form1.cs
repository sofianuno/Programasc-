﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RepasoExamen3
{
    public partial class Form1 : Form
    {
        private int fila= -1, columna= -1;
        private string nombreB = "";
        public Form1()
        {
            InitializeComponent();
            cargarDatos();
          
            dataDatos.AllowUserToAddRows = false;// es para quitar fila vacia
            dataDatos.ReadOnly = true;// evita ediccion directa
                
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {

            StreamWriter streamWriter;
            string nombre = txtNombre.Text;
            string edad = txtEdad.Text;
            streamWriter = File.AppendText("nombre.csv");
            streamWriter.WriteLine(nombre + "," + edad);
            streamWriter.Close();
            cargarDatos();
            MessageBox.Show("Datos guardados", "Mensaje");
            txtNombre.Text = "";
            txtEdad.Text = "";

        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void dataDatos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            fila = e.RowIndex;
            columna = e.ColumnIndex;
            nombreB = dataDatos.Rows[fila].Cells[1].Value.ToString();
            if (columna == 3)
            {
                EliminarNombre(nombreB);
                MessageBox.Show("Nombre Eliminado", "Mensaje");
                cargarDatos();
            }
        }

        private void EliminarNombre(string n)
        {
            if (fila != -1)
            {
                StreamReader archivo = File.OpenText("nombre.csv");
                string renglon = "";
                StreamWriter aux = null;
                do
                {
                    try
                    {
                        renglon = archivo.ReadLine();
                        if (renglon != null)
                        {
                            string[] partes = renglon.Split(',');// para separar las campos
                            if (!partes[0].Equals(n))
                            {
                                aux = File.AppendText("prueba.csv");
                                string cadena = partes[0] + "," + partes[1];
                                aux.WriteLine(cadena);
                                aux.Close();
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error", "Error");
                    }
                } while (renglon != null);
                archivo.Close();
                File.Delete("nombre.csv");// para eliminar el archivo original
                if (File.Exists("prueba.csv"))
                {
                    File.Move("prueba.csv", "nombre.csv");
                    File.Delete("prueba.csv");
                }
                fila = -1;
                columna = -1;
                nombreB = "";
            }

        }

        private void modificarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fila != -1)
            {
                StreamReader archivo = File.OpenText("nombre.csv");
                string renglon = "";
                StreamWriter aux = null;// archivo temporal auxiliar
                do
                {
                    try
                    {
                        renglon = archivo.ReadLine();// aqui es para leer una linea
                        if (renglon != null)
                        {
                            string[] partes = renglon.Split(',');
                            if (partes[0].Equals(nombreB))
                            {
                                txtNombre.Text = partes[0];
                                txtEdad.Text = partes[1];
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error", "Error");
                    }
                } while (renglon != null);
                archivo.Close();
            }
            else
            {
                MessageBox.Show("elige una fila", "Error");
            }
        }

        private void modificar2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string n = txtNombre.Text;
            string ed = txtEdad.Text;
            StreamReader archivo = File.OpenText("nombre.csv");
            string renglon = "";
            StreamWriter aux = null;
            do
            {
                try
                {
                    renglon = archivo.ReadLine();
                    if (renglon != null)
                    {
                        string[] partes = renglon.Split(',');
                        if (!partes[0].Equals(nombreB))
                        {
                            aux = File.AppendText("prueba.csv");
                            string cadena = partes[0] + "," + partes[1];
                            aux.WriteLine(cadena);
                            aux.Close();

                        }
                        else
                        {
                            MessageBox.Show(n);
                            if (n.Length == 0)
                            {
                                n = partes[0];
                            }
                            if (ed.Length == 0)
                            {
                                ed = partes[1];
                            }
                            aux = File.AppendText("prueba.csv");
                            string cadena = n + "," + ed;
                            aux.WriteLine(cadena);
                            aux.Close();
                        }

                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error", "Error");
                }
            } while (renglon != null);
            archivo.Close();
            File.Delete("nombre.csv");
            if (File.Exists("prueba.csv"))
            {
                File.Move("prueba.csv", "nombre.csv");
                File.Delete("prueba.csv");

            }
            fila = -1;
            columna = -1;
            nombreB = "";
        }

        private void cargarDatos()
        {
            if (File.Exists("nombre.csv"))
            {
                StreamReader streamReader = File.OpenText("nombre.csv");
                string renglon = "";
                int con = 0;
                dataDatos.Rows.Clear();
                do
                {
                    try
                    {
                        renglon = streamReader.ReadLine();
                        if (renglon != null)
                        {
                            string[] partes = renglon.Split(' ');
                            con++;
                            dataDatos.Rows.Add(con, partes[0], partes[1]);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error", "Error");

                    }
                } while (renglon != null);
                streamReader.Close();
                
                
            }

        }
    }
}
