﻿namespace practica2p3
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panelRegristro = new Panel();
            txtEdad = new TextBox();
            texNombre = new TextBox();
            txtcorreo = new TextBox();
            panelMostrar = new Panel();
            dataCorreos = new DataGridView();
            CORREO = new DataGridViewTextBoxColumn();
            ID = new DataGridViewTextBoxColumn();
            NOMBRE = new DataGridViewTextBoxColumn();
            EDAD = new DataGridViewTextBoxColumn();
            EDITAR = new DataGridViewImageColumn();
            ELIMINAR = new DataGridViewImageColumn();
            menuStrip1 = new MenuStrip();
            mnuASalir = new ToolStripMenuItem();
            mnuAAgregar = new ToolStripMenuItem();
            mnuAMostrar = new ToolStripMenuItem();
            mnuAsalirse = new ToolStripMenuItem();
            panelRegristro.SuspendLayout();
            panelMostrar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataCorreos).BeginInit();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // panelRegristro
            // 
            panelRegristro.Controls.Add(txtEdad);
            panelRegristro.Controls.Add(texNombre);
            panelRegristro.Controls.Add(txtcorreo);
            panelRegristro.Location = new Point(12, 33);
            panelRegristro.Name = "panelRegristro";
            panelRegristro.Size = new Size(776, 101);
            panelRegristro.TabIndex = 0;
            panelRegristro.Visible = false;
            panelRegristro.Paint += panel1_Paint;
            // 
            // txtEdad
            // 
            txtEdad.Font = new Font("Arial Narrow", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txtEdad.ForeColor = SystemColors.ActiveCaptionText;
            txtEdad.Location = new Point(546, 43);
            txtEdad.Name = "txtEdad";
            txtEdad.Size = new Size(200, 25);
            txtEdad.TabIndex = 2;
            txtEdad.Text = "Escribe una edad";
            txtEdad.Enter += textBox3_Enter;
            txtEdad.KeyPress += txtEdad_KeyPress;
            txtEdad.Leave += txtEdad_Leave;
            // 
            // texNombre
            // 
            texNombre.Font = new Font("Arial Narrow", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            texNombre.ForeColor = SystemColors.ActiveCaptionText;
            texNombre.Location = new Point(255, 42);
            texNombre.Name = "texNombre";
            texNombre.Size = new Size(193, 27);
            texNombre.TabIndex = 1;
            texNombre.Text = "Escribe un nombre";
            texNombre.Enter += texNombre_Enter;
            texNombre.KeyPress += texNombre_KeyPress;
            texNombre.Leave += texNombre_Leave;
            // 
            // txtcorreo
            // 
            txtcorreo.Font = new Font("Arial Narrow", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txtcorreo.ForeColor = SystemColors.ActiveCaptionText;
            txtcorreo.Location = new Point(25, 41);
            txtcorreo.Name = "txtcorreo";
            txtcorreo.Size = new Size(166, 25);
            txtcorreo.TabIndex = 0;
            txtcorreo.Text = "Escribe un correo";
            txtcorreo.Enter += txtcorreo_Enter;
            txtcorreo.KeyPress += txtcorreo_KeyPress;
            txtcorreo.Leave += txtcorreo_Leave;
            // 
            // panelMostrar
            // 
            panelMostrar.Controls.Add(dataCorreos);
            panelMostrar.Location = new Point(12, 172);
            panelMostrar.Name = "panelMostrar";
            panelMostrar.Size = new Size(776, 249);
            panelMostrar.TabIndex = 1;
            // 
            // dataCorreos
            // 
            dataCorreos.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataCorreos.Columns.AddRange(new DataGridViewColumn[] { CORREO, ID, NOMBRE, EDAD, EDITAR, ELIMINAR });
            dataCorreos.Location = new Point(3, 3);
            dataCorreos.Name = "dataCorreos";
            dataCorreos.RowHeadersWidth = 51;
            dataCorreos.Size = new Size(770, 249);
            dataCorreos.TabIndex = 0;
            dataCorreos.CellClick += dataCorreos_CellClick;
            // 
            // CORREO
            // 
            CORREO.HeaderText = "ID";
            CORREO.MinimumWidth = 6;
            CORREO.Name = "CORREO";
            CORREO.Width = 40;
            // 
            // ID
            // 
            ID.HeaderText = "CORREO";
            ID.MinimumWidth = 6;
            ID.Name = "ID";
            ID.Width = 125;
            // 
            // NOMBRE
            // 
            NOMBRE.HeaderText = "NOMBRE";
            NOMBRE.MinimumWidth = 6;
            NOMBRE.Name = "NOMBRE";
            NOMBRE.Width = 125;
            // 
            // EDAD
            // 
            EDAD.HeaderText = "EDAD";
            EDAD.MinimumWidth = 6;
            EDAD.Name = "EDAD";
            EDAD.Width = 50;
            // 
            // EDITAR
            // 
            EDITAR.HeaderText = "EDITAR";
            EDITAR.Image = Properties.Resources.th__1_;
            EDITAR.ImageLayout = DataGridViewImageCellLayout.Zoom;
            EDITAR.MinimumWidth = 6;
            EDITAR.Name = "EDITAR";
            EDITAR.Width = 80;
            // 
            // ELIMINAR
            // 
            ELIMINAR.HeaderText = "ELIMINAR";
            ELIMINAR.Image = Properties.Resources.th;
            ELIMINAR.ImageLayout = DataGridViewImageCellLayout.Zoom;
            ELIMINAR.MinimumWidth = 6;
            ELIMINAR.Name = "ELIMINAR";
            ELIMINAR.Width = 80;
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(20, 20);
            menuStrip1.Items.AddRange(new ToolStripItem[] { mnuASalir });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(800, 28);
            menuStrip1.TabIndex = 2;
            menuStrip1.Text = "menuStrip1";
            // 
            // mnuASalir
            // 
            mnuASalir.DropDownItems.AddRange(new ToolStripItem[] { mnuAAgregar, mnuAMostrar, mnuAsalirse });
            mnuASalir.Name = "mnuASalir";
            mnuASalir.Size = new Size(86, 24);
            mnuASalir.Text = "ARCHIVO";
            // 
            // mnuAAgregar
            // 
            mnuAAgregar.Name = "mnuAAgregar";
            mnuAAgregar.Size = new Size(160, 26);
            mnuAAgregar.Text = "AGREGAR";
            mnuAAgregar.Click += mnuAAgregar_Click;
            // 
            // mnuAMostrar
            // 
            mnuAMostrar.Name = "mnuAMostrar";
            mnuAMostrar.Size = new Size(160, 26);
            mnuAMostrar.Text = "MOSTRAR";
            mnuAMostrar.Click += mnuAMostrar_Click;
            // 
            // mnuAsalirse
            // 
            mnuAsalirse.Name = "mnuAsalirse";
            mnuAsalirse.Size = new Size(160, 26);
            mnuAsalirse.Text = "SALIR";
            mnuAsalirse.Click += mnuAsalirse_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(panelMostrar);
            Controls.Add(panelRegristro);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            MaximumSize = new Size(818, 497);
            MinimumSize = new Size(818, 497);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Regristro de correos";
            panelRegristro.ResumeLayout(false);
            panelRegristro.PerformLayout();
            panelMostrar.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataCorreos).EndInit();
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panelRegristro;
        private Panel panelMostrar;
        private TextBox txtEdad;
        private TextBox texNombre;
        private TextBox txtcorreo;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem mnuASalir;
        private ToolStripMenuItem mnuAAgregar;
        private ToolStripMenuItem mnuAMostrar;
        private ToolStripMenuItem mnuAsalirse;
        private DataGridView dataCorreos;
        private DataGridViewTextBoxColumn CORREO;
        private DataGridViewTextBoxColumn ID;
        private DataGridViewTextBoxColumn NOMBRE;
        private DataGridViewTextBoxColumn EDAD;
        private DataGridViewImageColumn EDITAR;
        private DataGridViewImageColumn ELIMINAR;
    }
}
