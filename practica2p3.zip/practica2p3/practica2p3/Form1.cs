namespace practica2p3
{
    public partial class Form1 : Form
    {
        private bool estado1 = false;
        private bool estado2 = false;
        private int _columna = -1;
        private int _id = -1;
        private string correo, nombre, edad;
        


        public Form1()
        {

            InitializeComponent();
            txtcorreo.ForeColor = Color.Gray;
            texNombre.ForeColor = Color.Gray;
            txtEdad.ForeColor = Color.Gray;
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void mnuAAgregar_Click(object sender, EventArgs e)
        {
            estado1 = !estado1;
            panelRegristro.Visible = estado1;
        }

        private void mnuAMostrar_Click(object sender, EventArgs e)
        {
            estado2 = !estado2;
            panelMostrar.Visible = estado2;
            dataCorreos.Rows.Clear();
            cargardatos();

        }

        private void mnuAsalirse_Click(object sender, EventArgs e)
        {
            Application.Exit();

        }

        private void texNombre_Enter(object sender, EventArgs e)
        {
            if (texNombre.Text == "Escribe un nombre")
            {
                texNombre.Text = "";
                texNombre.ForeColor = Color.Black;

            }
        }

        private void texNombre_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(texNombre.Text))
            {
                texNombre.Text = "Escribe un nombre";
                texNombre.ForeColor = Color.Gray;

            }

        }

        private void txtcorreo_Enter(object sender, EventArgs e)
        {
            if (txtcorreo.Text == "Escribe un correo")
            {
                txtcorreo.Text = "";
                txtcorreo.ForeColor = Color.Black;

            }

        }

        private void txtcorreo_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtcorreo.Text))
            {
                txtcorreo.Text = "Escribe un correo";
                txtcorreo.ForeColor = Color.Gray;

            }

        }

        private void textBox3_Enter(object sender, EventArgs e)
        {

            if (txtEdad.Text == "Escribe una edad")
            {
                txtEdad.Text = "";
                txtEdad.ForeColor = Color.Black;

            }

        }
        private void cargardatos()
        {
            if (File.Exists("datos.csv"))
            {

                StreamReader streamReader = File.OpenText("datos.csv");
                string renglon = " ";
                int c = 0;
                do
                {
                    try
                    {
                        renglon = streamReader.ReadLine();
                        if (renglon != null)
                        {
                            string[] partes = renglon.Split(',');
                            c++;
                            dataCorreos.Rows.Add(c.ToString(), partes[0], partes[1], partes[2]);

                        }

                    }
                    catch (Exception ex)

                    {
                        MessageBox.Show("Errorrrrr", "Error");
                    }

                } while (renglon != null);
                streamReader.Close();

            }
            else
            {
                MessageBox.Show("Error, no hay datos guardados");
            }
        }




        private void txtEdad_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtEdad.Text))
            {
                txtEdad.Text = "Escribe una edad";
                txtEdad.ForeColor = Color.Gray;

            }

        }

        private void txtcorreo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 97 && e.KeyChar <= 122) || (e.KeyChar == 08)
                || (e.KeyChar == 46)
                || (e.KeyChar == 64)
                || (e.KeyChar == 95)
                || (e.KeyChar >= 48 && e.KeyChar <= 57))
            {
                if (e.KeyChar == 13)
                {
                    Guardar();
                }

            }
            else
            {
                e.Handled = true;
                MessageBox.Show("ERROR DE DATOS", "ERROR");
            }
        }

        private void texNombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 97 && e.KeyChar <= 122)
               || (e.KeyChar == 08)
               || (e.KeyChar == 32)
               || (e.KeyChar >= 65 && e.KeyChar <= 90))

            {
                if (e.KeyChar == 13)
                {
                    Guardar();
                }


            }
            else
            {
                e.Handled = true;
                MessageBox.Show("ERROR DE DATOS", "ERROR");
            }
        }
        private void Guardar()
        {
            string correo = txtcorreo.Text;
            string nombre = texNombre.Text;
            string edad = txtEdad.Text;
            if (correo.Equals("Escribe un correo") || nombre.Equals("Escribe un nombre") || edad.Equals("Escribe una edad"))
            {
                MessageBox.Show("Datos vacios");
            }
            else
            {
                if (correo.Equals("Escribe un correo") || nombre.Equals("Escribe un nombre") || edad.Equals("Escribe una edad"))
                {
                    MessageBox.Show("Datos vacios");
                }
                else
                {
                    StreamWriter archivo = null;
                    archivo = File.AppendText("datos.csv");
                    archivo.WriteLine(correo + "," + nombre + "," + edad);
                    archivo.Close();
                    MessageBox.Show("Datos guardados", "Aviso");
                    dataCorreos.Rows.Clear();
                    cargardatos();
                }

            }
        }
        private void EliminarDatos()
        {
            if (_id != -1)
            {
               
                StreamReader archivo = File.OpenText("datos.csv");
                string renglon = " ";
                StreamWriter aux = null;
                int c = 0;
                do
                {
                    try
                    {
                        renglon = archivo.ReadLine();
                        if (renglon != null)
                        {
                            string[] partes = renglon.Split(',');

                            if (partes[0].Equals(c))
                            {
                                MessageBox.Show("Eliminar", "Eliminar");
                            }
                            else
                            {
                                aux = File.AppendText("prueba.csv");
                                string cadena = partes[0] + "," + partes[1];
                                aux.WriteLine(cadena);
                                aux.Close();

                            }
                        }

                    }
                    catch (Exception ex)

                    {
                        MessageBox.Show("Error", "Error");
                    }

                } while (renglon != null);

                archivo.Close();
                File.Delete("datos.csv");
                if (File.Exists("prueba.csv"))
                {
                    File.Move("prueba.csv", "datos.csv");
                    File.Delete("prueba.csv");

                }
                dataCorreos.Rows.RemoveAt(_id);
            }
        }

        private void txtEdad_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 48 && e.KeyChar <= 57)
                || (e.KeyChar == 08))

            {
                if (e.KeyChar == 13)
                {
                    Guardar();
                }

            }
            else
            {
                e.Handled = true;
                MessageBox.Show("ERROR DE DATOS", "ERROR");
            }
            if (e.KeyChar == 13)
            {
                Guardar();
            }
        }

        private void dataCorreos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            _id = e.RowIndex;
            _columna = e.ColumnIndex;
            if (_id != -1)
            {
                correo = dataCorreos.Rows[_id].Cells[1].Value.ToString();
                nombre = dataCorreos.Rows[_id].Cells[2].Value.ToString();
                edad = dataCorreos.Rows[_id].Cells[3].Value.ToString();


            }
            else
            {
                MessageBox.Show("Elige un elemento de la lista");
            }
            if (_columna == 4)
            {
                txtcorreo.Text = correo;
                texNombre.Text = nombre;
                txtEdad.Text = edad;
                panelRegristro.Visible = true;
                txtcorreo.ForeColor = Color.Black;
                texNombre.ForeColor = Color.Black;
                txtEdad.ForeColor = Color.Black;
            }

            if (_columna == 5)
            {
                EliminarDatos();
            }
        }
    }
}
