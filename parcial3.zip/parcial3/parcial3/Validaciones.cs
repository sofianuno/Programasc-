﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

class validaciones
{
    public bool validarnombre(String n)
    {
        bool r = false;
        //@"^[a-zA-Z _]$"; Letras y espacios 
        r = (Regex.IsMatch(n, @"^[a-zA-Z -]+$"));
        return r;
    }

    public bool validaredad(String e)
    {


        bool r = Regex.IsMatch(e, @"^[0-9]+$");
        {

            return r;
        }

    }
    public bool validarsexo(String s)
    {
        bool r = false;
        
        r = (Regex.IsMatch(s, @"^[a-zA-Z -]+$"));
        return r;
    }
}
