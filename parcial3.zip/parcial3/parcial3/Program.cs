﻿/*Utilizando dos archivos vamos a llenar un archivo con 10 datos que involucre nombre edad y sexo de 10 personas*/

using System.Reflection.PortableExecutable;

class program
{
    static validaciones va = new validaciones();
    static archivos ar = new archivos();
  
    static void Main(string[] args)
    {
        string n, e, s;
        n = PedirNombre();
        e = PedirEdad();
        s = PedirSexo();
        A.Leer(n, e, s);
        

    }
    
   
    static string PedirNombre()
    {
        string n;
        int contador = 0;
        while (true)
        {
            Console.WriteLine("Escribe el nombre de una persona");
            n = Console.ReadLine();
            if (contador < 10);
            if (va.validarnombre(n))
            {
                Console.WriteLine("nombre correcto");
                contador++;
                break;  
            }
            else
            {
                Console.WriteLine("Nombre incorrecto");
            }
            
          
        }
        return n;
    }
    static string PedirEdad()
    {
        string e;
        int contador = 0;
        while (true)
        {
            Console.WriteLine("Escribe la Edad");
            e = Console.ReadLine();
            if (contador > 10);
            if (va.validaredad(e))
            {
                Console.WriteLine("Edad Correcta");
                contador++;
                
                break;
            }
            else
            {
                Console.WriteLine("Edad incorrecta solo numeros");
            }
            
        }
        return e;
    }
    static string PedirSexo()
    {
        string s;
        int contador = 0;
        while (true)
        {
            Console.WriteLine("Escribe el Sexo");
            s = Console.ReadLine();
            if (contador <10);
            if (va.validarsexo(s))
            {
                Console.WriteLine("Sexo correcto");
                contador++;
                break;
            }
            else
            {
                Console.WriteLine("Sexo incorrecto,solo letras");
            }
            
        }
        return s;
    }








}