﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class archivos
{
    public void Leer(string n, string s, string e){
        string lp = "personas.txt";
        StreamWriter archivo = File.AppendText(lp);
        archivo.WriteLine(n + " " + e );
    }
}
