﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Programa1P3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            StreamWriter archivo = null;
            validaciones val = new validaciones();
            //MessageBox.Show("HOLA MUNDO");
            string nombre = txtnombre.Text;
            string edad = txtedad.Text;
            if (val.validarnombre(nombre) && val.validaredad(edad)) {
                archivo = File.AppendText("Datos.csv");
                string cadena = nombre + "  , " + edad;
                archivo.WriteLine(cadena);
                archivo.Close();
                txtnombre.Text = "";
                txtedad.Text = "";
                MessageBox.Show("Datos guardados", "Aviso");
            }
            else
            {
                MessageBox.Show("Datos incorrectos", "Error");
                txtnombre.Text = "";
                txtedad.Text = "";
            }
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void txtedad_TextChanged(object sender, EventArgs e)
        {

        }

        private void mnuAMostrar_Click(object sender, EventArgs e)
        {
            Mostrar mostrar = new Mostrar();
            mostrar.ShowDialog(this);
            
        }

        private void txtnombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 65 && e.KeyChar <= 90) 
                || (e.KeyChar >= 97 && e.KeyChar <= 122)
                    || (e.KeyChar == 32) || (e.KeyChar == 08))
            {

            }
            else
            {
                e.Handled = true;
                MessageBox.Show("Error dato no valido");
            }
        }

        private void txtedad_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 48 && e.KeyChar <= 57) || (e.KeyChar == 08))
            {

            }
            else
            {
                e.Handled = true;
                MessageBox.Show("Error dato no valido");
            }
        }

        private void txtnombre_TextChanged(object sender, EventArgs e)
        {

        }
    }

}
