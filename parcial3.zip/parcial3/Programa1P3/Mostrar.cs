﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Programa1P3
{
    public partial class Mostrar : Form

    {
        private int _id =-1;
        private string u = "";
        private string p = "";
        private int columna = -1;
        public Mostrar()
        {
            InitializeComponent();
            cargarDatos();

        }
        private void cargarDatos()
        {
            if (File.Exists("datos.csv"))
            {


            
            StreamReader streamReader = File.OpenText("datos.csv");
            string renglon = " ";
            int c = 0;
            do {
                try {
                    renglon = streamReader.ReadLine();
                    if (renglon != null)
                    {
                        string[] partes = renglon.Split(',');
                        c++;
                        dataDatos.Rows.Add(c.ToString(), partes[0], partes[1]);

                    }
                
                }catch(Exception ex)

                {
                    MessageBox.Show("Error", "Error");
                }

            } while (renglon != null);
            streamReader.Close();

            }
            else
            {
                MessageBox.Show("Error, no hay datos guardados");
            }
        }

        private void mnuAPrincipal_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void mnuASalir_Click(object sender, EventArgs e)
        {


        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            dataDatos.Rows.Clear();
            cargarDatos();
        }

        private void Mostrar_Load(object sender, EventArgs e)
        {

        }

        private void dataDatos_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            
        }
        private void Eliminardato()
        {
            if (_id != -1)
            {
                dataDatos.Rows.RemoveAt(_id);
                StreamReader archivo = File.OpenText("datos.csv");
                string renglon = " ";
                StreamWriter aux = null;
                int c = 0;
                do
                {
                    try
                    {
                        renglon = archivo.ReadLine();
                        if (renglon != null)
                        {
                            string[] partes = renglon.Split(',');

                            if (partes[0].Equals(u))
                            {
                            }
                            else
                            {
                                aux = File.AppendText("prueba.csv");
                                string cadena = partes[0] + "," + partes[1];
                                aux.WriteLine(cadena);
                                aux.Close();

                            }
                        }

                    }
                    catch (Exception ex)

                    {
                        MessageBox.Show("Error", "Error");
                    }

                } while (renglon != null);

                archivo.Close();
                File.Delete("datos.csv");
                if (File.Exists("prueba.csv")){ 
                    File.Move("prueba.csv", "datos.csv");
                    File.Delete("prueba.csv");
                  
                }
                dataDatos.Rows.RemoveAt(_id);
            }

        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
        }
        private void Modificar(string u, string p)
        {
            if (_id != -1)
            {
                dataDatos.Rows.RemoveAt(_id);
                StreamReader archivo = File.OpenText("datos.csv");
                string renglon = " ";
                StreamWriter aux = null;
                int c = 0;
                do
                {
                    try
                    {
                        renglon = archivo.ReadLine();
                        if (renglon != null)
                        {
                            string[] partes = renglon.Split(',');

                            if (partes[0].Equals(u))
                            {
                                string us = Interaction.InputBox("Ingresa un nombre",
                                    "Agregar Nombre");
                                string ed = Interaction.InputBox("Ingresa una Edad",
                                    "Agregar Edad");
                                if (us.Length == 0)
                                {
                                    us = u;
                                }
                                if (ed.Length == 0)
                                {
                                    ed = p;
                                }
                                aux = File.AppendText("prueba.csv");
                                string cadena = us + " " + ed;
                                aux.WriteLine(cadena);
                                aux.Close();
                            }
                            else
                            {
                                aux = File.AppendText("prueba.csv");
                                string cadena = partes[0] + "," + partes[1];
                                aux.WriteLine(cadena);
                                aux.Close();

                            }
                        }

                    }
                    catch (Exception ex)

                    {
                        MessageBox.Show("Error", "Error");
                    }

                } while (renglon != null);

                archivo.Close();
                File.Delete("datos.csv");
                File.Move("prueba.csv", "datos.csv");
                File.Delete("prueba.csv");
                dataDatos.Rows.RemoveAt(_id);
            }
        }

        private void dataDatos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            _id = e.RowIndex;
            columna = e.ColumnIndex;
            if (_id != -1)
            {
                u = dataDatos.Rows[_id].Cells[1].Value.ToString();
                p = dataDatos.Rows[_id].Cells[2].Value.ToString();
               
                
            }
            else
            {
                MessageBox.Show("Elige un elemento de la lista");
            }
            if (columna == 3)
            {
                Modificar(u,p);
                dataDatos.Rows.Clear();
                cargarDatos();
            }
            else if (columna == 4)
            {
                MessageBoxButtons botones = MessageBoxButtons.YesNo;
                MessageBoxIcon icon = MessageBoxIcon.Question;
                DialogResult respuesta = MessageBox.Show("¿Estas seguro?","Alerta" ,botones, icon);
                if (respuesta == DialogResult.Yes)
                {
                    Eliminardato();
                    dataDatos.Rows.Clear();
                    cargarDatos();

                }
               
            }

        }
    }
}